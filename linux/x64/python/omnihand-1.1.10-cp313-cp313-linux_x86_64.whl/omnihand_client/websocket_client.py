"""Asynchronous WebSocket client for OmniHand Server."""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator, Mapping, Sequence
from contextlib import suppress
from typing import Any

from .errors import OmniHandClientError, OmniHandConnectionError

JsonObject = dict[str, Any]


class OmniHandWebSocketClient:
    """Asynchronous WebSocket client for commands and stream subscriptions."""

    def __init__(self, host: str = "127.0.0.1", port: int = 8000,
                 timeout: float = 10.0) -> None:
        if not host:
            raise ValueError("host must not be empty")
        if not 1 <= port <= 65535:
            raise ValueError("port must be in [1, 65535]")
        self.host = host
        self.port = port
        self.timeout = timeout
        url_host = f"[{host}]" if ":" in host and not host.startswith("[") else host
        self.url = f"ws://{url_host}:{port}/ws"
        self._connection: Any = None
        self._reader_task: asyncio.Task[None] | None = None
        self._pending: dict[int, asyncio.Future[Any]] = {}
        self._events: asyncio.Queue[JsonObject] = asyncio.Queue()
        self._request_id = 0
        self._send_lock = asyncio.Lock()

    async def connect(self) -> "OmniHandWebSocketClient":
        if self._connection is not None:
            return self
        try:
            from websockets.asyncio.client import connect
        except ImportError:
            try:
                from websockets import connect
            except ImportError as exc:
                raise ImportError(
                    "WebSocket support requires: pip install omnihand[client]"
                ) from exc
        self._connection = await connect(self.url, open_timeout=self.timeout)
        self._reader_task = asyncio.create_task(self._read_messages())
        return self

    async def close(self) -> None:
        connection, self._connection = self._connection, None
        if connection is not None:
            await connection.close()
        if self._reader_task is not None:
            self._reader_task.cancel()
            with suppress(asyncio.CancelledError):
                await self._reader_task
            self._reader_task = None
        error = OmniHandConnectionError("WebSocket connection is closed")
        for future in self._pending.values():
            if not future.done():
                future.set_exception(error)
        self._pending.clear()

    async def __aenter__(self) -> "OmniHandWebSocketClient":
        return await self.connect()

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    async def _read_messages(self) -> None:
        try:
            async for raw_message in self._connection:
                message = json.loads(raw_message)
                if message.get("type") == "result":
                    future = self._pending.pop(message.get("request_id"), None)
                    if future is not None and not future.done():
                        future.set_result(message)
                elif message.get("type") == "event":
                    await self._events.put(message)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            error = OmniHandConnectionError(f"WebSocket connection failed: {exc}")
            for future in self._pending.values():
                if not future.done():
                    future.set_exception(error)
            self._pending.clear()

    async def request(self, request_type: str, **fields: Any) -> Any:
        if self._connection is None:
            await self.connect()
        loop = asyncio.get_running_loop()
        async with self._send_lock:
            self._request_id += 1
            request_id = self._request_id
            future: asyncio.Future[Any] = loop.create_future()
            self._pending[request_id] = future
            try:
                await self._connection.send(json.dumps(
                    {"type": request_type, "request_id": request_id, **fields}
                ))
            except Exception:
                self._pending.pop(request_id, None)
                raise
        try:
            response = await asyncio.wait_for(future, timeout=self.timeout)
        except TimeoutError as exc:
            self._pending.pop(request_id, None)
            raise OmniHandConnectionError(
                f"WebSocket request timed out: {request_type}"
            ) from exc
        if not response.get("ok"):
            raise OmniHandClientError(
                str(response.get("error", "WebSocket request failed")), response=response
            )
        return response.get("result")

    async def list_hands(self) -> list[JsonObject]:
        return await self.request("list")

    async def create_hand(self, hand_type: str, conn_method: str,
                          conn_config: Mapping[str, Any] | None = None, *,
                          hand_side: str = "left") -> JsonObject:
        return await self.request(
            "create", hand_type=hand_type, hand_side=hand_side,
            conn_method=conn_method, conn_config=dict(conn_config or {}),
        )

    async def describe_hand(self, hand_id: int) -> JsonObject:
        return await self.request("describe", hand_id=hand_id)

    async def remove_hand(self, hand_id: int) -> Any:
        return await self.request("remove", hand_id=hand_id)

    async def methods(self, *, hand_id: int | None = None,
                      product_type: str | None = None) -> JsonObject:
        if (hand_id is None) == (product_type is None):
            raise ValueError("specify exactly one of hand_id or product_type")
        fields = {"hand_id": hand_id} if hand_id is not None else {"product_type": product_type}
        return await self.request("methods", **fields)

    async def call(self, hand_id: int, method: str,
                   params: Mapping[str, Any] | None = None) -> Any:
        return await self.request(
            "call", hand_id=hand_id, method=method, params=dict(params or {})
        )

    async def subscribe(self, hand_id: int, streams: Sequence[str]) -> JsonObject:
        return await self.request("subscribe", hand_id=hand_id, streams=list(streams))

    async def unsubscribe(self, hand_id: int, streams: Sequence[str]) -> JsonObject:
        return await self.request("unsubscribe", hand_id=hand_id, streams=list(streams))

    async def next_event(self, timeout: float | None = None) -> JsonObject:
        if timeout is None:
            return await self._events.get()
        try:
            return await asyncio.wait_for(self._events.get(), timeout=timeout)
        except TimeoutError as exc:
            raise OmniHandConnectionError("timed out waiting for a WebSocket event") from exc

    async def events(self) -> AsyncIterator[JsonObject]:
        while self._connection is not None:
            yield await self.next_event()


__all__ = ["OmniHandWebSocketClient"]
