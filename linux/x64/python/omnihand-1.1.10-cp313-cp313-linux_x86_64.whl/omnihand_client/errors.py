"""Errors shared by the REST and WebSocket clients."""

from typing import Any


class OmniHandClientError(RuntimeError):
    """A request was rejected by OmniHand Server."""

    def __init__(
        self,
        detail: str,
        *,
        status_code: int | None = None,
        error_code: str | None = None,
        response: Any = None,
    ) -> None:
        super().__init__(detail)
        self.detail = detail
        self.status_code = status_code
        self.error_code = error_code
        self.response = response


class OmniHandConnectionError(OmniHandClientError):
    """The client could not communicate with OmniHand Server."""


__all__ = ["OmniHandClientError", "OmniHandConnectionError"]
