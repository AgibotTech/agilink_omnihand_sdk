"""Synchronous REST client for OmniHand Server."""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from .errors import OmniHandClientError, OmniHandConnectionError


JsonObject = dict[str, Any]


@dataclass
class RemoteHand:
    """A hand session managed by a remote OmniHand Server."""

    _client: "OmniHandRestClient"
    hand_id: int
    summary: JsonObject
    _closed: bool = False

    def describe(self) -> JsonObject:
        return self._client.describe_hand(self.hand_id)

    def methods(self) -> JsonObject:
        return self._client.methods(hand_id=self.hand_id)

    def call(self, method: str, params: Mapping[str, Any] | None = None, **kwargs: Any) -> Any:
        if params is not None and kwargs:
            raise TypeError("pass method parameters either as params or keyword arguments")
        return self._client.call(self.hand_id, method, params or kwargs)

    def close(self) -> Any:
        if self._closed:
            return None
        result = self._client.remove_hand(self.hand_id)
        self._closed = True
        return result

    def __enter__(self) -> "RemoteHand":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


class OmniHandRestClient:
    """Synchronous REST client for OmniHand Server."""

    def __init__(self, host: str = "127.0.0.1", port: int = 8000,
                 timeout: float = 10.0) -> None:
        if not host:
            raise ValueError("host must not be empty")
        if not 1 <= port <= 65535:
            raise ValueError("port must be in [1, 65535]")
        self.host = host
        self.port = port
        self.timeout = timeout
        url_host = f"[{host}]" if ":" in host and not host.startswith("[") else host
        self.base_url = f"http://{url_host}:{port}"

    def request(self, method: str, path: str, *, query: Mapping[str, Any] | None = None,
                body: Any = None) -> Any:
        url = f"{self.base_url}/{path.lstrip('/')}"
        if query:
            url = f"{url}?{urlencode(query)}"
        data = None if body is None else json.dumps(body).encode("utf-8")
        request = Request(
            url, data=data, method=method.upper(),
            headers={"Accept": "application/json", "Content-Type": "application/json"},
        )
        try:
            with urlopen(request, timeout=self.timeout) as response:
                return self._decode_response(response.read())
        except HTTPError as exc:
            payload = self._decode_response(exc.read())
            detail = self._error_detail(payload, f"HTTP {exc.code}")
            error_code = payload.get("error_code") if isinstance(payload, dict) else None
            if error_code is None and isinstance(payload, dict):
                error_code = payload.get("code")
            raise OmniHandClientError(
                detail, status_code=exc.code, error_code=error_code, response=payload
            ) from exc
        except (URLError, TimeoutError, OSError) as exc:
            raise OmniHandConnectionError(f"failed to connect to {url}: {exc}") from exc

    @staticmethod
    def _decode_response(payload: bytes) -> Any:
        if not payload:
            return None
        try:
            return json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise OmniHandClientError("server returned invalid JSON") from exc

    @staticmethod
    def _error_detail(payload: Any, fallback: str) -> str:
        if isinstance(payload, dict):
            for key in ("detail", "error", "message"):
                value = payload.get(key)
                if isinstance(value, str) and value:
                    return value
        return fallback

    def health(self) -> JsonObject:
        return self.request("GET", "/health")

    def vendor_info(self) -> JsonObject:
        return self.request("GET", "/v1/hands/vendor-info")

    def list_hands(self) -> list[JsonObject]:
        return self.request("GET", "/v1/hands")

    def list_product_types(self) -> list[str]:
        return self.request("GET", "/v1/hands/type", query={"query": "product_type"})["type"]

    def list_connection_types(self) -> list[str]:
        return self.request("GET", "/v1/hands/type", query={"query": "conn_type"})["type"]

    def connection_configs(self) -> Any:
        return self.request("GET", "/v1/hands/type", query={"query": "conn_config"})["type"]

    def methods(self, *, hand_id: int | None = None,
                product_type: str | None = None) -> JsonObject:
        if (hand_id is None) == (product_type is None):
            raise ValueError("specify exactly one of hand_id or product_type")
        if hand_id is not None:
            return self.request("GET", f"/v1/hands/{hand_id}/methods")
        return self.request("GET", "/v1/hands/methods", query={"product_type": product_type})

    def create_hand(self, hand_type: str, conn_method: str,
                    conn_config: Mapping[str, Any] | None = None, *,
                    hand_side: str = "left") -> RemoteHand:
        summary = self.request(
            "POST", "/v1/hands",
            body={"hand_type": hand_type, "hand_side": hand_side,
                  "conn_method": conn_method, "conn_config": dict(conn_config or {})},
        )
        return RemoteHand(self, int(summary["hand_id"]), summary)

    def describe_hand(self, hand_id: int) -> JsonObject:
        return self.request("GET", f"/v1/hands/{hand_id}")

    def remove_hand(self, hand_id: int) -> Any:
        return self.request("DELETE", f"/v1/hands/{hand_id}")

    def call(self, hand_id: int, method: str,
             params: Mapping[str, Any] | None = None) -> Any:
        return self.request(
            "POST", f"/v1/hands/{hand_id}/methods",
            query={"method": method}, body=dict(params or {}),
        )

    def websocket(self) -> "OmniHandWebSocketClient":
        from .websocket_client import OmniHandWebSocketClient

        return OmniHandWebSocketClient(self.host, self.port, timeout=self.timeout)


__all__ = ["OmniHandRestClient", "RemoteHand"]
