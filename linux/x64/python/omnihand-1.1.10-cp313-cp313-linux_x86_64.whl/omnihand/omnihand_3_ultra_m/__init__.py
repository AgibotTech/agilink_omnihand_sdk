"""OmniHand 3 Ultra M T1.3/T1.5 solver module."""

from ..omnihand_core import H3UMRevision, OmniHand3UltraMSolver

__all__ = ["H3UMRevision", "OmniHand3UltraMSolver"]
