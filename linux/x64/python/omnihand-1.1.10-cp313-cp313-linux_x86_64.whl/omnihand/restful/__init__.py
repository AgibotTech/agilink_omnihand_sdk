"""Legacy namespace; use :class:`omnihand.OmniHandServer`."""

__all__ = []
