# Copyright (c) 2025, Agibot Co., Ltd.
# AGILINK OmniHand SDK is licensed under Mulan PSL v2

"""
AGILINK OmniHand SDK Python Interface

This package supports OmniHand 2025 (O10), OmniHand Pro 2025 (O12),
OmniHand 3 Lite (H3L), OmniHand 3 Ultra M (H3UM), and OmniPicker 3 (OP3).

Usage:
    from omnihand import OmniHand2025, OmniHandPro2025, OmniHand3Lite, HandType, Finger
    
    # For OmniHand 2025 (O10, 10 DOF):
    hand = OmniHand2025.create_hand_by_zlgcan(
        hand_type=HandType.RIGHT,
        hand_device_id=OmniHand2025.kDefaultHandDeviceId,
        canfd_device_id=0,
        canfd_channel_id=0
    )
    
    # For OmniHand Pro 2025 (O12, 12 DOF):
    hand = OmniHandPro2025.create_hand_by_zlgcan(
        hand_type=HandType.LEFT,
        hand_device_id=OmniHandPro2025.kDefaultHandDeviceId,
        canfd_device_id=0,
        canfd_channel_id=0
    )
    
    # For OmniHand 3 Lite (O4, 4 DOF):
    hand = OmniHand3Lite.create_hand_by_zlgcan(
        hand_type=HandType.LEFT,
        hand_device_id=OmniHand3Lite.kDefaultHandDeviceId,
        canfd_device_id=0,
        canfd_channel_id=0
    )
    
"""

import os

# Python 3.8+ uses an explicit DLL search path on Windows. Retain the handle
# for the lifetime of the package; otherwise the directory is removed again.
_dll_directory_handles = []
if os.name == "nt" and hasattr(os, "add_dll_directory"):
    _dll_directory_handles.append(os.add_dll_directory(os.path.dirname(__file__)))

from .omnihand_core import (
    # Product-specific classes
    OmniHand2025,
    OmniHandPro2025,
    OmniHand3Lite,
    H3LModel,
    OmniHand3UltraM,
    H3UMRevision,
    OmniPicker3,
    # Common types
    HandType,
    ProductType,
    ControlMode,
    MixControlMode,
    Finger,
    OmniHand2025Gesture,
    OmniHand3LiteGesture,
    OmniPicker3Gesture,
    OmniHandPro2025Gesture,
    CommuParams,
    DeviceInfo,
    Version,
    VendorInfo,
    JointMotorErrorReport,
    JointPosiStatus,
    AllJointPosiStatus,
    HandDetailInfo,
    JointDetailInfo,
    H3UMMotorDiagnosticInfo,
    MixCtrl,
    MixCtrlFrameResult,
    MixCtrlResult,
    TactileSensorDataU16,
    # O10-specific types
    TactileSensorData,
    # O12-specific types
    TactileSensor3DData,
    TactilePoint3DI16,
    TactileSensorData3DI16,
    TactileSensorResultantForce3DI16,
    # Solvers
    OmniHand2025Solver,
    OmniHandPro2025Solver,
    OmniHand3UltraMSolver,
    OmniHand3LiteSolver,
)


_H3UM_ERROR_BIT_NAMES = (
    'encoder_comm_timeout',
    'calibration_error',
    'over_voltage',
    'under_voltage',
    'over_temperature',
    'torque_saturation',
    'param_crc_error',
    'homing_error',
    'position_following_error',
    'velocity_following_error',
    'over_current',
    'inner_encoder_crc_error',
    'outer_encoder_crc_error',
    'encoder_multi_turn_error',
    'angle_identify_fail',
    'bit15_reserved',
)


def h3um_error_report_to_string(value: int) -> str:
    value &= 0xFFFF
    if value == 0:
        return '0'
    return ','.join(
        name for i, name in enumerate(_H3UM_ERROR_BIT_NAMES) if value & (1 << i)
    )

__all__ = [
    # Product-specific classes
    "OmniHand2025",
    "OmniHandPro2025",
    "OmniHand3Lite",
    "H3LModel",
    "OmniHand3UltraM",
    "H3UMRevision",
    "OmniPicker3",
    # Common types
    "HandType",
    "ProductType",
    "ControlMode",
    "MixControlMode",
    "Finger",
    "OmniHand2025Gesture",
    "OmniHand3LiteGesture",
    "OmniPicker3Gesture",
    "OmniHandPro2025Gesture",
    "CommuParams",
    "DeviceInfo",
    "Version",
    "VendorInfo",
    "JointMotorErrorReport",
    "JointPosiStatus",
    "AllJointPosiStatus",
    "HandDetailInfo",
    "JointDetailInfo",
    "H3UMMotorDiagnosticInfo",
    "MixCtrl",
    "MixCtrlFrameResult",
    "MixCtrlResult",
    "TactileSensorDataU16",
    # O10-specific types
    "TactileSensorData",
    # O12-specific types
    "TactileSensor3DData",
    "TactilePoint3DI16",
    "TactileSensorData3DI16",
    "TactileSensorResultantForce3DI16",
    # Solvers
    "OmniHand2025Solver",
    "OmniHandPro2025Solver",
    "OmniHand3UltraMSolver",
    "OmniHand3LiteSolver",
    # H3U_M error report utility
    "h3um_error_report_to_string",
]
