# Copyright (c) 2025, Agibot Co., Ltd.
# AGILINK OmniHand SDK is licensed under Mulan PSL v2

"""OmniHand 3 Ultra M T1.3/T1.5 kinematics solver type stubs."""

from typing import List
from typing import overload
from ..omnihand_core import H3UMRevision

ACTIVE_JOINT_COUNT: int
ACTUATOR_INPUT_MIN: int
ACTUATOR_INPUT_MAX: int

class OmniHand3UltraMSolver:
    """Per-joint linear rad <-> actuator-input solver for H3UM T1.3/T1.5."""

    @overload
    def __init__(self, is_left_hand: bool) -> None:
        """Create a T1.3 solver."""
        ...

    @overload
    def __init__(self, is_left_hand: bool, revision: H3UMRevision) -> None:
        """Create a solver for the selected H3UM revision."""
        ...

    def active_joint_pos_to_actuator_input(
        self, active_joint_pos: List[float]
    ) -> List[int]:
        """Convert 20/21 joint angles (rad) to actuator inputs in [0, 4096]."""
        ...

    def actuator_input_to_active_joint_pos(
        self, actuator_input: List[int]
    ) -> List[float]:
        """Convert 20/21 actuator inputs to joint angles (rad)."""
        ...

    def convert_active_joint_angles(
        self,
        active_joint_pos: List[float],
        source_is_left: bool,
        target_is_left: bool,
    ) -> List[float]:
        """Convert active-joint angles between left/right conventions."""
        ...
