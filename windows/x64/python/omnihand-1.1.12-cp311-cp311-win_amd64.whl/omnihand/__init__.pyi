# Copyright (c) 2025, Agibot Co., Ltd.
# AGILINK OmniHand SDK is licensed under Mulan PSL v2

"""
OmniHand 2025 SDK Python Type Stubs
Supports both OmniHand 2025 (O10, 10 DOF) and OmniHand 2025 Pro (O12, 12 DOF)
"""

from typing import List, Callable, Optional, Union, overload
from enum import IntEnum

class HandType(IntEnum):
    LEFT = 0
    RIGHT = 1
    UNKNOWN = 255

class ProductType(IntEnum):
    OMNIHAND_2025 = 0
    OMNIHAND_PRO_2025 = 1
    OMNIHAND_3_LITE = 3
    OMNIHAND_3_ULTRA_M = 4
    OMNI_PICKER_3 = 5
    UNKNOWN = 255

class H3UMRevision(IntEnum):
    T1P3 = 20
    T1P5 = 21

class H3LModel(IntEnum):
    H3L_S = 0
    H3L_M = 1

class ControlMode(IntEnum):
    POSITION = 0
    SERVO = 1
    VELOCITY = 2
    TORQUE = 3
    VOLTAGE = 4
    PROFILE_POSITION = 7
    UNKNOWN = 10

class MixControlMode(IntEnum):
    POSITION_TORQUE = 0x3
    VELOCITY_TORQUE = 0x4
    POSITION_VELOCITY_TORQUE = 0x5

class Finger(IntEnum):
    ALL_FINGERS = 0
    THUMB = 1
    INDEX = 2
    MIDDLE = 3
    RING = 4
    LITTLE = 5
    PALM = 6
    DORSUM = 7
    UNKNOWN = 255

class OmniHand2025Gesture(IntEnum):
    OMNIHAND_2025_GESTURE_ALL_ZERO = 0
    OMNIHAND_2025_GESTURE_PAPER = 1
    OMNIHAND_2025_GESTURE_FIST1 = 2
    OMNIHAND_2025_GESTURE_FIST2 = 3
    OMNIHAND_2025_GESTURE_OK = 4
    OMNIHAND_2025_GESTURE_ONE_HANDED_FINGER_HEART = 5
    OMNIHAND_2025_GESTURE_LIKE = 6
    OMNIHAND_2025_GESTURE_ILY = 7
    OMNIHAND_2025_GESTURE_NUM1 = 8
    OMNIHAND_2025_GESTURE_NUM2 = 9
    OMNIHAND_2025_GESTURE_NUM3 = 10
    OMNIHAND_2025_GESTURE_NUM4 = 11
    OMNIHAND_2025_GESTURE_NUM6 = 12
    OMNIHAND_2025_GESTURE_NUM8 = 13
    OMNIHAND_2025_GESTURE_HAND_HEART1 = 14
    OMNIHAND_2025_GESTURE_HAND_HEART2 = 15
    OMNIHAND_2025_GESTURE_HAND_HEART3 = 16
    OMNIHAND_2025_GESTURE_CLASPING = 17

class OmniHand3LiteGesture(IntEnum):
    OMNI_HAND_3_LITE_GESTURE_OPEN = 0
    OMNI_HAND_3_LITE_GESTURE_OK = 1
    OMNI_HAND_3_LITE_GESTURE_ONE_HANDED_FINGER_HEART = 2
    OMNI_HAND_3_LITE_GESTURE_LIKE = 3
    OMNI_HAND_3_LITE_GESTURE_SIDE_FIST = 4
    OMNI_HAND_3_LITE_GESTURE_FRONT_FIST = 5
    OMNI_HAND_3_LITE_GESTURE_PRAYER = 6
    OMNI_HAND_3_LITE_GESTURE_HAND_HEART1 = 7
    OMNI_HAND_3_LITE_GESTURE_HAND_HEART2 = 8
    OMNI_HAND_3_LITE_GESTURE_HAND_HEART3 = 9
    OMNI_HAND_3_LITE_GESTURE_POINT = 10
    OMNI_HAND_3_LITE_GESTURE_BOW = 11
    OMNI_HAND_3_LITE_GESTURE_WAVE = 12
    OMNI_HAND_3_LITE_GESTURE_NUM1 = 13
    OMNI_HAND_3_LITE_GESTURE_NUM3 = 14
    OMNI_HAND_3_LITE_GESTURE_NUM4 = 15
    OMNI_HAND_3_LITE_GESTURE_NUM7 = 16
    OMNI_HAND_3_LITE_GESTURE_NUM8 = 17

class OmniPicker3Gesture(IntEnum):
    OMNIPICKER_3_GESTURE_ZERO = 0
    OMNIPICKER_3_GESTURE_HALF_OPEN = 1
    OMNIPICKER_3_GESTURE_FULL_OPEN = 2

class CommuParams:
    bitrate: int
    sample_point: int
    dbitrate: int
    dsample_point: int
    def __str__(self) -> str: ...

class Version:
    major: int
    minor: int
    patch: int
    res: int
    def __str__(self) -> str: ...

class VendorInfo:
    product_model: str
    product_seq_num: str
    hardware_version: Version
    software_version: Version
    voltage: int  # uint16_t supply voltage in mV (0..65535)
    dof: int
    def __str__(self) -> str: ...

class DeviceInfo:
    hand_device_id: int
    commu_params: CommuParams
    def __str__(self) -> str: ...

class JointMotorErrorReport:
    stalled: bool
    overheat: bool
    over_current: bool
    motor_except: bool
    commu_except: bool

class JointPosiStatus:
    position: int
    running_code: int
    error_code: int
    def __str__(self) -> str: ...

class AllJointPosiStatus:
    positions: List[int]
    running_code: int
    error_code: int
    def __str__(self) -> str: ...

class HandDetailInfo:
    hand_bus_voltage: int
    hand_bus_current: int
    hand_temperature: int
    def __str__(self) -> str: ...

class JointDetailInfo:
    hand_bus_voltage: int
    hand_bus_current: int
    hand_temperature: int
    joint_position: int
    joint_velocity: int
    joint_current: int
    joint_temperature: int
    joint_bus_voltage: int
    joint_running_code: int
    joint_error_code: int
    joint_debug: int
    def __str__(self) -> str: ...

class H3UMMotorDiagnosticInfo:
    """T1.5 register 0x81 reply, with all fields in protocol units."""
    motor_real_inside_location: int
    motor_real_outside_location: int
    motor_real_current: int  # mA
    motor_real_voltage: int  # mV
    motor_real_speed: int  # 0.1 degree/s
    motor_real_temperature: int  # 0.1 degree Celsius
    motor_real_status: int  # uint32 status mask
    motor_target_current: int  # mA
    motor_target_speed: int  # 0.1 degree/s
    motor_target_location: int
    motor_tx_count: int
    motor_rx_count: int
    broadcast_tx_count: int
    broadcast_rx_count: int
    motor_mode: int
    def __init__(self) -> None: ...

class MixCtrl:
    joint_index: int
    ctrl_mode: int
    tgt_posi: Optional[int]
    tgt_velo: Optional[int]
    tgt_torque: Optional[int]
    motor_status: Optional[int]

class MixCtrlFrameResult:
    sub_register: int
    feedback: List[MixCtrl]
    running_code: int
    error_code: int
    replied: bool

class MixCtrlResult:
    frames: List[MixCtrlFrameResult]
    all_frames_sent: bool
    def complete(self) -> bool: ...

class Int16Bound:
    min_value: int
    max_value: int

class Int16Range:
    min_value: int
    max_value: int
    default_value: int

class FloatBound:
    min_value: float
    max_value: float

class TactileSensorData:
    """OmniHand 2025 (O10) 1D tactile sensor data"""
    sensor_id: int  # Finger enum value
    data: List[int]  # Raw sensor data (unit: 1g, max: 255g)

class TactileSensorDataU16:
    """H3L/OP3 1D tactile sensor data."""
    sensor_id: Finger
    data: List[int]

class TactileSensor3DData:
    """OmniHand Pro 2025 (O12) 3D tactile sensor data"""
    online_state: int
    channel_values: List[int]  # 9 channels
    normal_force: int
    tangent_force: int
    tangent_force_angle: int
    capacitive_approach: List[int]  # 4 channels

class TactilePoint3DI16:
    x: int
    y: int
    z: int

class TactileSensorData3DI16:
    sensor_id: Finger
    points: List[TactilePoint3DI16]

class TactileSensorResultantForce3DI16:
    sensor_id: Finger
    force: TactilePoint3DI16

class OmniHand:
    """Unified OmniHand class supporting both O10 and O12"""
    
    @staticmethod
    def create_hand_by_zlgcan(
        product_type: int,
        hand_type: int = 0,
        hand_device_id: int = 1,
        canfd_device_id: int = 0,
        canfd_channel_id: int = 0
    ) -> "OmniHand":
        """Create OmniHand instance over ZLG CAN."""
        ...
    
    @staticmethod
    def create_hand_by_zlgcan(
        product_type: int,
        hand_type: int,
        hand_device_id: int,
        usbcanfd_serial_number: str,
        canfd_channel_id: int = 0
    ) -> "OmniHand":
        """Create OmniHand instance over ZLG CAN (by serial number)."""
        ...
    
    @staticmethod
    def create_hand_by_rs485(
        product_type: int,
        hand_type: int = 0,
        hand_device_id: int = 1,
        uart_port: str = "/dev/ttyUSB0",
        baudrate: int = 460800
    ) -> "OmniHand":
        """Create OmniHand instance over RS485 (OmniHand 2025 only)."""
        ...
    
    @staticmethod
    def create_hand_by_hcan(
        product_type: int,
        hand_type: int = 0,
        hand_device_id: int = 1,
        canfd_device_id: int = 0,
        canfd_channel_id: int = 0
    ) -> "OmniHand":
        """Create OmniHand instance over HCAN USB CANFD (by device ID)."""
        ...
    
    @staticmethod
    def create_hand_by_hcan(
        product_type: int,
        hand_type: int,
        hand_device_id: int,
        hcan_serial_number: str,
        canfd_channel_id: int = 0
    ) -> "OmniHand":
        """Create OmniHand instance over HCAN USB CANFD (by serial number)."""
        ...
    
    @staticmethod
    def create_hand_socketcan(
        product_type: int,
        hand_type: int = 0,
        hand_device_id: int = 1,
        can_interface: str = "can0"
    ) -> "OmniHand":
        """Create OmniHand instance over SocketCAN (Linux only)."""
        ...
    
    def init(self) -> bool:
        """Check initialization status."""
        ...
    
    def get_product_type(self) -> int:
        """Get product type."""
        ...

    def get_num_of_joint_motors(self) -> int: ...
    def get_doa(self) -> int: ...
    def get_dop(self) -> int: ...
    
    def get_vendor_info(self) -> VendorInfo: ...
    def get_device_info(self) -> DeviceInfo: ...
    
    def set_joint_position(self, joint_motor_index: int, posi: int) -> None:
        """
        Set single joint motor position
        
        Args:
            joint_motor_index: Joint motor index
            posi: Motor position value
                - OmniHand 2025 (O10): range 0-4096
                - OmniHand Pro 2025 (O12): range 0-2000
        """
        ...
    
    def get_joint_position(self, joint_motor_index: int) -> int:
        """
        Get single joint motor position
        
        Args:
            joint_motor_index: Joint motor index
            
        Returns:
            Motor position value
                - OmniHand 2025 (O10): range 0-4096
                - OmniHand Pro 2025 (O12): range 0-2000
        """
        ...
    
    def set_all_joint_positions(self, vec_posi: List[int]) -> List[int]:
        """
        Set all joint motor positions and return actual positions
        
        Args:
            vec_posi: List of motor position values
                - OmniHand 2025 (O10): 10 values, each in range 0-4096
                - OmniHand Pro 2025 (O12): 12 values, each in range 0-2000
        
        Returns:
            List of actual positions from device response. Empty list on failure.
        """
        ...
    
    def get_all_joint_positions(self) -> List[int]:
        """
        Get all joint motor positions
        
        Returns:
            List of motor position values
                - OmniHand 2025 (O10): 10 values, each in range 0-4096
                - OmniHand Pro 2025 (O12): 12 values, each in range 0-2000
        """
        ...

    def set_joint_position_with_status(
        self, joint_motor_index: int, position: int
    ) -> JointPosiStatus: ...
    def get_joint_position_with_status(
        self, joint_motor_index: int
    ) -> JointPosiStatus: ...
    def set_all_joint_positions_with_status(
        self, positions: List[int]
    ) -> AllJointPosiStatus: ...
    def get_all_joint_positions_with_status(self) -> AllJointPosiStatus: ...
    
    def set_all_active_joint_angles(self, angles: List[float]) -> None: ...
    def set_hand_gesture(self, gesture_num: int = 1) -> None: ...  # default is product-specific (O10: 1=FIST1)
    def get_all_active_joint_angles(self) -> List[float]: ...
    def get_all_joint_angles(self, active_joint_angles: Optional[List[float]] = None) -> List[float]: ...
    def get_all_joint_angles_from_motor_positions(
        self, motor_positions: List[int]
    ) -> List[float]: ...
    def convert_active_joint_angles(
        self,
        angles: List[float],
        source_hand: HandType,
        target_hand: HandType,
    ) -> List[float]: ...
    
    def set_joint_velocity(self, joint_motor_index: int, velo: int) -> None: ...
    def get_joint_velocity(self, joint_motor_index: int) -> int: ...
    def set_all_joint_velocities(self, vec_velo: List[int]) -> None: ...
    def get_all_joint_velocities(self) -> List[int]: ...
    
    def get_tactile_sensor_data(self, finger_index: int) -> List[int]:
        """Get tactile sensor data (OmniHand 2025 O10 only, returns vector<uint8_t>)."""
        ...
    
    def get_tactile_sensor_3d_data(self, finger_index: int) -> TactileSensor3DData:
        """Get 3D tactile sensor data (OmniHand Pro 2025 O12 only, returns TactileSensor3DData)."""
        ...
    
    def get_all_tactile_sensor_data_raw(self) -> List[TactileSensorData]:
        """Get all 1D tactile sensor raw data (OmniHand 2025 O10 only, returns vector<TactileSensorData>, full resolution)."""
        ...
    
    def get_tactile_sensor_data_raw(self, finger_index: int) -> TactileSensorData:
        """Get single 1D tactile sensor raw data (OmniHand 2025 O10 only, returns TactileSensorData, full resolution)."""
        ...
    
    def set_current_threshold(self, joint_motor_index: int, current_threshold: int) -> None: ...
    def get_current_threshold(self, joint_motor_index: int) -> int: ...
    def set_all_current_thresholds(self, current_thresholds: List[int]) -> None: ...
    def get_all_current_thresholds(self) -> List[int]: ...
    
    def mix_control_by_pt(self, positions: List[int], torques: List[int]) -> List[MixCtrl]: ...
    def mix_control_by_pvt(self, positions: List[int], velocities: List[int], torques: List[int]) -> List[MixCtrl]: ...
    def mix_control_with_status(self, controls: List[MixCtrl]) -> MixCtrlResult: ...
    @overload
    def mix_control_by_pt_with_status(
        self, joint_motor_index: int, position: int, torque: int
    ) -> MixCtrlResult: ...
    @overload
    def mix_control_by_pt_with_status(
        self, positions: List[int], torques: List[int]
    ) -> MixCtrlResult: ...
    @overload
    def mix_control_by_pvt_with_status(
        self, joint_motor_index: int, position: int, velocity: int, torque: int
    ) -> MixCtrlResult: ...
    @overload
    def mix_control_by_pvt_with_status(
        self, positions: List[int], velocities: List[int], torques: List[int]
    ) -> MixCtrlResult: ...

    def get_all_joint_detail_info(self) -> HandDetailInfo: ...
    def get_joint_detail_info(self, joint_index: int) -> JointDetailInfo: ...
    
    def get_error_report(self, joint_motor_index: int) -> JointMotorErrorReport: ...
    def get_all_error_reports(self) -> List[JointMotorErrorReport]: ...
    def set_error_report_period(self, joint_motor_index: int, period: int) -> None: ...
    def set_all_error_report_periods(self, vec_period: List[int]) -> None: ...
    
    def get_temperature_report(self, joint_motor_index: int) -> int: ...
    def get_all_temperature_reports(self) -> List[int]: ...
    def set_temperature_report_period(self, joint_motor_index: int, period: int) -> None: ...
    def set_all_temperature_report_periods(self, vec_period: List[int]) -> None: ...
    
    def get_current_report(self, joint_motor_index: int) -> int: ...
    def get_all_current_reports(self) -> List[int]: ...
    def set_current_report_period(self, joint_motor_index: int, period: int) -> None: ...
    def set_all_current_report_periods(self, vec_period: List[int]) -> None: ...
    
    def show_data_details(self, show: bool) -> None: ...
    
    def set_request_interval(self, milliseconds: int) -> None:
        """
        Set request interval to control CAN bus communication rate
        
        Args:
            milliseconds: Minimum interval between requests in milliseconds (0-100ms, 0 = no limit, default: 30ms)
        """
        ...
    def get_request_interval(self) -> int:
        """
        Get current request interval setting
        
        Returns:
            Request interval in milliseconds (0 = no limit, 0 for RS485 = not applicable)
        """
        ...
    def set_frame_recv_timeout(self, milliseconds: int) -> None:
        """
        Set frame reception timeout
        
        Args:
            milliseconds: Timeout for receiving a single frame (10-1000ms, default: 50ms)
        
        Note:
            - This timeout applies to both single-frame and multi-frame reception
            - For multi-frame reception, this timeout applies to each frame individually
            - Only applies to CAN communication. RS485 communication is not affected.
            - Serial port communication (RS485) does not support this interface.
        """
        ...
    def get_frame_recv_timeout(self) -> int:
        """
        Get current frame reception timeout setting
        
        Returns:
            Frame reception timeout in milliseconds (0 for RS485 = not applicable)
        
        Note:
            Serial port communication (RS485) always returns 0 (not applicable).
        """
        ...

# --- Product-line classes (omnihand_core) ---

class OmniHand2025(OmniHand):
    kDegreesOfActiveFreedom: int
    kDegreesOfPassiveFreedom: int
    kDefaultHandDeviceId: int
    def set_device_id(self, device_id: int) -> None: ...
    def set_hand_gesture(
        self,
        gesture: OmniHand2025Gesture = OmniHand2025Gesture.OMNIHAND_2025_GESTURE_FIST1,
    ) -> None: ...
    def get_num_of_tactile_sensors(self) -> int: ...
    def get_num_of_tactile_points(self, finger_index: int) -> int: ...
    def get_len_of_tactile_datum(self, finger_index: int) -> int: ...
    def get_num_of_replied_tactile_frames(self, finger_index: int) -> int: ...
    def get_sn_of_tactile_sensor(self, finger_index: int) -> str: ...
    def get_all_tactile_sensor_data(self) -> List[TactileSensorData]: ...
    def get_hand_device_id_by_broadcast(self) -> int: ...
    def set_hand_device_id_by_broadcast(self, device_id: int) -> bool: ...
class OmniHandPro2025(OmniHand):
    kDegreesOfActiveFreedom: int
    kDefaultHandDeviceId: int
    def set_device_id(self, device_id: int) -> None: ...
    def set_control_mode(self, joint_motor_index: int, mode: int) -> None: ...
    def get_control_mode(self, joint_motor_index: int) -> int: ...
    def set_all_control_modes(self, ctrl_modes: List[int]) -> None: ...
    def get_all_control_modes(self) -> List[int]: ...
    def set_joint_torque(self, joint_motor_index: int, torque: int) -> None: ...
    def get_joint_torque(self, joint_motor_index: int) -> int: ...
    def set_all_joint_torques(self, vec_torque: List[int]) -> None: ...
    def get_all_joint_torques(self) -> List[int]: ...
    def set_joint_voltage(self, joint_motor_index: int, voltage: int) -> None: ...
    # O12 firmware versions up to and including 1.2.15 do not support voltage readback.
    def get_joint_voltage(self, joint_motor_index: int) -> int: ...
    def set_all_joint_voltages(self, vec_voltage: List[int]) -> None: ...
    # O12 firmware versions up to and including 1.2.15 do not support voltage readback.
    def get_all_joint_voltages(self) -> List[int]: ...

class OmniHand3Lite(OmniHand):
    kDegreesOfActiveFreedom: int
    kDefaultHandDeviceId: int
    def set_device_id(self, device_id: int) -> None: ...
    def get_hand_device_id_by_broadcast(self) -> int: ...
    def set_hand_device_id_by_broadcast(self, device_id: int) -> bool: ...
    @overload
    @staticmethod
    def create_hand_by_zlgcan(
        hand_type: int = 0,
        hand_device_id: int = 1,
        canfd_device_id: int = 0,
        canfd_channel_id: int = 0,
    ) -> "OmniHand3Lite": ...
    @overload
    @staticmethod
    def create_hand_by_zlgcan(
        hand_type: int,
        hand_device_id: int,
        usbcanfd_serial_number: str,
        canfd_channel_id: int = 0,
    ) -> "OmniHand3Lite": ...
    @staticmethod
    def create_hand_by_zlgcan_tcp(
        hand_type: int,
        hand_device_id: int,
        host: str,
        port: int,
        canfd_channel_id: int = 0,
    ) -> "OmniHand3Lite": ...
    @staticmethod
    def create_hand_socketcan(
        hand_type: int = 0,
        hand_device_id: int = 1,
        can_interface: str = "can0",
    ) -> "OmniHand3Lite": ...
    @overload
    @staticmethod
    def create_hand_by_hcan(
        hand_type: int = 0,
        hand_device_id: int = 1,
        canfd_device_id: int = 0,
        canfd_channel_id: int = 0,
    ) -> "OmniHand3Lite": ...
    @overload
    @staticmethod
    def create_hand_by_hcan(
        hand_type: int,
        hand_device_id: int,
        hcan_serial_number: str,
        canfd_channel_id: int = 0,
    ) -> "OmniHand3Lite": ...
    @staticmethod
    def create_hand_by_rs485(
        hand_type: int = 0,
        hand_device_id: int = 1,
        serial_port: str = "/dev/ttyUSB0",
        baud_rate: int = 460800,
    ) -> "OmniHand3Lite": ...
    def get_num_of_tactile_sensors(self) -> int: ...
    def get_num_of_tactile_points(self, finger_index: int) -> int: ...
    def init_tactile_points_map(self) -> bool: ...
    def get_len_of_tactile_datum(self, finger_index: int) -> int: ...
    def get_num_of_replied_tactile_frames(self, finger_index: int) -> int: ...
    def get_sn_of_tactile_sensor(self, finger_index: int) -> str: ...
    def get_sensor_order(self) -> List[Finger]: ...
    def get_tactile_sensor_data(self, finger_index: int) -> TactileSensorDataU16: ...
    def get_tactile_sensor_data_raw(self, finger_index: int) -> TactileSensorDataU16: ...
    def get_all_tactile_sensor_data_raw(self) -> List[TactileSensorDataU16]: ...
    def get_joint_names(self) -> List[str]: ...
    @staticmethod
    def get_min_max_motor_position(joint_motor_index: int) -> Int16Bound: ...
    @staticmethod
    def get_min_max_actual_motor_position(joint_motor_index: int) -> Int16Bound: ...
    @staticmethod
    def get_min_max_default_mix_ctrl_velocity(joint_motor_index: int) -> Int16Range: ...
    @staticmethod
    def get_min_max_default_mix_ctrl_torque(joint_motor_index: int) -> Int16Range: ...
    @staticmethod
    def get_min_max_activate_joint_angle(
        joint_motor_index: int,
        hand_type: int,
        model: H3LModel = H3LModel.H3L_S,
    ) -> FloatBound: ...
    def set_frame_send_timeout(self, milliseconds: int) -> None: ...
    def get_frame_send_timeout(self) -> int: ...
    def set_hand_gesture(
        self,
        gesture: OmniHand3LiteGesture = OmniHand3LiteGesture.OMNI_HAND_3_LITE_GESTURE_OK,
    ) -> None: ...
    def get_hand_gesture(self, gesture: OmniHand3LiteGesture) -> List[int]: ...
    def set_all_active_joint_angles(self, angles: List[float]) -> List[float]: ...
    def get_all_active_joint_angles(self) -> List[float]: ...
    def set_joint_velocity(self, joint_motor_index: int, velocity: int) -> None: ...
    def set_all_joint_velocities(self, velocities: List[int]) -> None: ...
    def get_joint_velocity(self, joint_motor_index: int) -> int: ...
    def get_all_joint_velocities(self) -> List[int]: ...
    @overload
    def mix_control_by_pt(
        self, joint_motor_index: int, position: int, torque: int
    ) -> MixCtrl: ...
    @overload
    def mix_control_by_pt(
        self, positions: List[int], torques: List[int]
    ) -> List[MixCtrl]: ...
    @overload
    def mix_control_by_pvt(
        self, joint_motor_index: int, position: int, velocity: int, torque: int
    ) -> MixCtrl: ...
    @overload
    def mix_control_by_pvt(
        self, positions: List[int], velocities: List[int], torques: List[int]
    ) -> List[MixCtrl]: ...

class OmniPicker3(OmniHand):
    kDegreesOfActiveFreedom: int
    kDefaultHandDeviceId: int
    @overload
    @staticmethod
    def create_hand_by_zlgcan(
        hand_type: int = HandType.UNKNOWN,
        hand_device_id: int = 1,
        canfd_device_id: int = 0,
        canfd_channel_id: int = 0,
    ) -> "OmniPicker3": ...
    @overload
    @staticmethod
    def create_hand_by_zlgcan(
        hand_type: int,
        hand_device_id: int,
        usbcanfd_serial_number: str,
        canfd_channel_id: int = 0,
    ) -> "OmniPicker3": ...
    @staticmethod
    def create_hand_by_zlgcan_tcp(
        hand_type: int,
        hand_device_id: int,
        host: str,
        port: int,
        canfd_channel_id: int = 0,
    ) -> "OmniPicker3": ...
    @staticmethod
    def create_hand_socketcan(
        hand_type: int = HandType.UNKNOWN,
        hand_device_id: int = 1,
        can_interface: str = "can0",
    ) -> "OmniPicker3": ...
    @overload
    @staticmethod
    def create_hand_by_hcan(
        hand_type: int = HandType.UNKNOWN,
        hand_device_id: int = 1,
        canfd_device_id: int = 0,
        canfd_channel_id: int = 0,
    ) -> "OmniPicker3": ...
    @overload
    @staticmethod
    def create_hand_by_hcan(
        hand_type: int,
        hand_device_id: int,
        hcan_serial_number: str,
        canfd_channel_id: int = 0,
    ) -> "OmniPicker3": ...
    @staticmethod
    def create_hand_by_rs485(
        hand_type: int = HandType.UNKNOWN,
        hand_device_id: int = 1,
        serial_port: str = "/dev/ttyUSB0",
        baud_rate: int = 460800,
    ) -> "OmniPicker3": ...
    def get_hand_device_id_by_broadcast(self) -> int: ...
    def set_frame_send_timeout(self, milliseconds: int) -> None: ...
    def get_frame_send_timeout(self) -> int: ...
    def get_joint_names(self) -> List[str]: ...
    @staticmethod
    def get_min_max_motor_position() -> Int16Bound: ...
    @staticmethod
    def get_min_max_mix_ctrl_torque() -> Int16Range: ...
    @staticmethod
    def get_min_max_stroke() -> Int16Bound: ...
    @staticmethod
    def get_min_max_stroke_mix_speed() -> Int16Range: ...
    @staticmethod
    def get_min_max_mix_ctrl_current() -> Int16Range: ...
    def set_joint_position(self, joint_motor_index: int, position: int) -> int: ...
    def get_joint_position(self, joint_motor_index: int) -> int: ...
    def set_all_joint_positions(self, positions: List[int]) -> List[int]: ...
    def get_all_joint_positions(self) -> List[int]: ...
    def mix_control_by_stroke(
        self,
        stroke: int,
        speed: Optional[int] = None,
        current: Optional[int] = None,
    ) -> Optional[int]: ...
    def get_stroke(self) -> Optional[int]: ...
    def set_gentle_grip(self, iq_limit_ma: Optional[int] = None) -> List[int]: ...
    def set_hand_gesture(
        self,
        gesture: OmniPicker3Gesture = OmniPicker3Gesture.OMNIPICKER_3_GESTURE_HALF_OPEN,
    ) -> None: ...
    def get_hand_gesture(self, gesture: OmniPicker3Gesture) -> List[int]: ...
    @overload
    def mix_control_by_pt(
        self, joint_motor_index: int, position: int, torque: int
    ) -> MixCtrl: ...
    @overload
    def mix_control_by_pt(
        self, positions: List[int], torques: List[int]
    ) -> List[MixCtrl]: ...
    def get_error_report(self, joint_motor_index: int) -> JointMotorErrorReport: ...
    def get_all_error_reports(self) -> List[JointMotorErrorReport]: ...
    def get_temperature_report(self, joint_motor_index: int) -> int: ...
    def get_all_temperature_reports(self) -> List[int]: ...
    def get_current_report(self, joint_motor_index: int) -> int: ...
    def get_all_current_reports(self) -> List[int]: ...
    def get_num_of_tactile_sensors(self) -> int: ...
    def get_num_of_tactile_points(self, finger: Finger) -> int: ...
    def init_tactile_points_map(self) -> bool: ...
    def get_len_of_tactile_datum(self, finger: Finger) -> int: ...
    def get_num_of_replied_tactile_frames(self, finger: Finger) -> int: ...
    def get_sn_of_tactile_sensor(self, finger: Finger) -> str: ...
    def get_sensor_order(self) -> List[Finger]: ...
    def get_tactile_sensor_data(self, finger: Finger) -> TactileSensorDataU16: ...
    def get_tactile_sensor_data_raw(self, finger: Finger) -> TactileSensorDataU16: ...
    def get_all_tactile_sensor_data_raw(self) -> List[TactileSensorDataU16]: ...

class OmniHand3LiteSolver:
    """Offline active-joint angle/actuator conversion for H3L."""
    @overload
    def __init__(self, is_left_hand: bool) -> None: ...
    @overload
    def __init__(self, is_left_hand: bool, model: H3LModel) -> None: ...
    def set_hand_gesture(self, gesture: OmniHand3LiteGesture) -> List[int]: ...
    def active_joint_pos_to_actuator_input(
        self, active_joint_pos: List[float]
    ) -> List[int]: ...
    def actuator_input_to_active_joint_pos(
        self, actuator_input: List[int]
    ) -> List[float]: ...
    @staticmethod
    def convert_active_joint_angles(
        active_joint_pos: List[float],
        source_is_left: bool,
        target_is_left: bool,
    ) -> List[float]: ...
    def single_active_joint_pos_to_actuator_input(
        self, joint_index: int, angle: float
    ) -> int: ...
    def single_actuator_input_to_active_joint_pos(
        self, joint_index: int, actuator_input: int
    ) -> float: ...
    @staticmethod
    def get_motor_position_range() -> Int16Bound: ...
    @staticmethod
    def get_active_joint_angle_range(
        joint_index: int, model: H3LModel = H3LModel.H3L_S
    ) -> FloatBound: ...
    def get_model(self) -> H3LModel: ...

class OmniHand3UltraMSolver:
    """Offline active-joint angle/actuator conversion for H3UM T1.3/T1.5."""
    @overload
    def __init__(self, is_left_hand: bool) -> None: ...
    @overload
    def __init__(self, is_left_hand: bool, revision: H3UMRevision) -> None: ...
    def active_joint_pos_to_actuator_input(
        self, active_joint_pos: List[float]
    ) -> List[int]: ...
    def actuator_input_to_active_joint_pos(
        self, actuator_input: List[int]
    ) -> List[float]: ...
    def convert_active_joint_angles(
        self,
        active_joint_pos: List[float],
        source_is_left: bool,
        target_is_left: bool,
    ) -> List[float]: ...

class OmniHand3UltraM(OmniHand):
    kT1P3DegreesOfActiveFreedom: int
    kT1P5DegreesOfActiveFreedom: int
    kT1P3DefaultHandDeviceId: int
    kT1P5DefaultHandDeviceId: int
    @overload
    @staticmethod
    def create_hand_by_zlgcan(
        hand_type: int = 0,
        hand_device_id: int = 9,
        canfd_device_id: int = 0,
        canfd_channel_id: int = 0,
        tactile_soc_ip: str = "192.168.99.2",
        tactile_soc_port: int = 19009,
    ) -> "OmniHand3UltraM": ...
    @overload
    @staticmethod
    def create_hand_by_zlgcan(
        hand_type: int,
        hand_device_id: int,
        usbcanfd_serial_number: str,
        canfd_channel_id: int = 0,
        tactile_soc_ip: str = "192.168.99.2",
        tactile_soc_port: int = 19009,
    ) -> "OmniHand3UltraM": ...
    @overload
    @staticmethod
    def create_hand_t1p5_by_zlgcan(
        hand_type: int = 0,
        hand_device_id: int = 1,
        canfd_device_id: int = 0,
        canfd_channel_id: int = 0,
    ) -> "OmniHand3UltraM": ...
    @overload
    @staticmethod
    def create_hand_t1p5_by_zlgcan(
        hand_type: int,
        hand_device_id: int,
        usbcanfd_serial_number: str,
        canfd_channel_id: int = 0,
    ) -> "OmniHand3UltraM": ...
    @staticmethod
    def create_hand_by_zlgcan_tcp(
        hand_type: int,
        hand_device_id: int,
        host: str,
        port: int,
        canfd_channel_id: int = 0,
        tactile_soc_ip: str = "192.168.99.2",
        tactile_soc_port: int = 19009,
    ) -> "OmniHand3UltraM": ...
    @staticmethod
    def create_hand_t1p5_by_zlgcan_tcp(
        hand_type: int,
        hand_device_id: int,
        host: str,
        port: int,
        canfd_channel_id: int = 0,
    ) -> "OmniHand3UltraM": ...
    @staticmethod
    def create_hand_socketcan(
        hand_type: int = 0,
        hand_device_id: int = 9,
        can_interface: str = "can0",
        tactile_soc_ip: str = "192.168.99.2",
        tactile_soc_port: int = 19009,
    ) -> "OmniHand3UltraM": ...
    @staticmethod
    def create_hand_t1p5_socketcan(
        hand_type: int = 0,
        hand_device_id: int = 1,
        can_interface: str = "can0",
    ) -> "OmniHand3UltraM": ...
    @overload
    @staticmethod
    def create_hand_by_hcan(
        hand_type: int = 0,
        hand_device_id: int = 9,
        canfd_device_id: int = 0,
        canfd_channel_id: int = 0,
        tactile_soc_ip: str = "192.168.99.2",
        tactile_soc_port: int = 19009,
    ) -> "OmniHand3UltraM": ...
    @overload
    @staticmethod
    def create_hand_by_hcan(
        hand_type: int,
        hand_device_id: int,
        hcan_serial_number: str,
        canfd_channel_id: int = 0,
        tactile_soc_ip: str = "192.168.99.2",
        tactile_soc_port: int = 19009,
    ) -> "OmniHand3UltraM": ...
    @overload
    @staticmethod
    def create_hand_t1p5_by_hcan(
        hand_type: int = 0,
        hand_device_id: int = 1,
        canfd_device_id: int = 0,
        canfd_channel_id: int = 0,
    ) -> "OmniHand3UltraM": ...
    @overload
    @staticmethod
    def create_hand_t1p5_by_hcan(
        hand_type: int,
        hand_device_id: int,
        hcan_serial_number: str,
        canfd_channel_id: int = 0,
    ) -> "OmniHand3UltraM": ...
    def set_device_id(self, device_id: int) -> None: ...
    def get_revision(self) -> H3UMRevision: ...
    def get_joint_names(self) -> List[str]: ...
    def set_joint_position(self, joint_motor_index: int, posi: int) -> None: ...
    def get_joint_position(self, joint_motor_index: int) -> int: ...
    def set_all_joint_positions(self, vec_posi: List[int]) -> List[int]: ...
    def get_all_joint_positions(self) -> List[int]: ...
    def set_all_active_joint_angles(self, angles: List[float]) -> List[float]: ...
    def set_hand_gesture(self, gesture_num: int = 1) -> None: ...
    def get_all_active_joint_angles(self) -> List[float]: ...
    @overload
    def get_all_joint_angles(self) -> List[float]: ...
    @overload
    def get_all_joint_angles(self, active_joint_angles: List[float]) -> List[float]: ...
    def get_joint_velocity(self, joint_motor_index: int) -> int: ...
    def get_all_joint_velocities(self) -> List[int]: ...
    def set_control_mode(self, joint_motor_index: int, mode: int) -> None: ...
    def get_control_mode(self, joint_motor_index: int) -> int: ...
    def set_all_control_modes(self, ctrl_modes: List[int]) -> None: ...
    def get_all_control_modes(self) -> List[int]: ...
    def set_current_threshold(
        self, joint_motor_index: int, current_threshold: int
    ) -> None: ...
    def get_current_threshold(self, joint_motor_index: int) -> int: ...
    def set_all_current_thresholds(self, current_thresholds: List[int]) -> None: ...
    def get_all_current_thresholds(self) -> List[int]: ...
    def get_error_report(self, joint_motor_index: int) -> JointMotorErrorReport: ...
    def get_all_error_reports(self) -> List[JointMotorErrorReport]: ...
    def get_temperature_report(self, joint_motor_index: int) -> int: ...
    def get_all_temperature_reports(self) -> List[int]: ...
    def get_current_report(self, joint_motor_index: int) -> int: ...
    def get_all_current_reports(self) -> List[int]: ...
    def get_temperature_of_palm(self) -> int: ...
    def get_motor_diagnostic_info(self, joint_motor_index: int) -> Optional[H3UMMotorDiagnosticInfo]:
        """Read one T1.5 motor (1~21); returns None on failure."""
        ...
    def get_temperature_of_power(self) -> int: ...
    def get_tactile_sensor_type(self) -> int:
        """T1.5: 1 = Jingzhigan, 2 = HuaweiKe, 0 = unknown; does not specify layout."""
        ...
    def init_tactile_points_map(self) -> bool: ...
    def get_num_of_tactile_sensors(self) -> int: ...
    def get_num_of_tactile_points(self, sensor: Finger) -> int: ...
    def get_len_of_tactile_datum(self, sensor: Finger) -> int: ...
    def get_tactile_sensor_data_raw(
        self, sensor: Finger
    ) -> TactileSensorData3DI16: ...
    def get_all_tactile_sensor_data_raw(self) -> List[TactileSensorData3DI16]: ...
    def get_tactile_sensor_resultant_force(
        self, sensor: Finger
    ) -> TactileSensorResultantForce3DI16: ...
    def get_all_tactile_sensor_resultant_forces(
        self,
    ) -> List[TactileSensorResultantForce3DI16]: ...
    def clear_all_error_report(self) -> None: ...
    def clear_error_report(self, joint_motor_index: int) -> None: ...
